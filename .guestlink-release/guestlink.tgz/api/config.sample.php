<?php
/**
 * Vows & Guests API configuration.
 *
 * SETUP: copy this file to config.php (same folder) and fill in real values.
 * config.php is gitignored — never commit real credentials.
 */

return [
  // --- MySQL (from cPanel > MySQL Databases) ---
  'db_host' => 'localhost',
  'db_name' => 'youruser_vowsguests',
  'db_user' => 'youruser_vowsapi',
  'db_pass' => 'CHANGE-ME-db-password',

  // --- JWT session signing secret ---
  // Generate one: run `php -r "echo bin2hex(random_bytes(32));"` or use any
  // long random string (64+ chars). Changing it logs everyone out.
  'jwt_secret' => 'CHANGE-ME-to-a-long-random-string',

  // Session lifetime in seconds (default 12 hours)
  'jwt_ttl' => 43200,

  // --- One-time setup key ---
  // Required to run setup.php (creates the superadmin). Pick a random string,
  // run setup once, then you may delete setup.php from the server.
  'setup_key' => 'CHANGE-ME-setup-key',

  // --- Superadmin bootstrap (used only by setup.php) ---
  'superadmin_username' => 'superadmin',
  'superadmin_password' => 'CHANGE-ME-strong-password',
  'superadmin_name'     => 'Bereket Girma',

  // --- CORS ---
  // Exact origin of the frontend, e.g. 'https://yourdomain.com'.
  // Leave '' if the frontend is served from the same domain as /api.
  'cors_origin' => '',
];
