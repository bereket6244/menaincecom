<?php
/**
 * One-time setup: creates/updates the superadmin account from config.php.
 *
 * Usage: https://yourdomain.com/api/setup.php?key=YOUR_SETUP_KEY
 * (the key is 'setup_key' in config.php)
 *
 * After running it successfully you should DELETE this file from the server,
 * or at minimum change 'setup_key' to a new random value.
 */

declare(strict_types=1);

require __DIR__ . '/lib/bootstrap.php';

global $CONFIG;

$key = (string)($_GET['key'] ?? '');
if ($key === '' || !hash_equals((string)$CONFIG['setup_key'], $key)) {
  json_error('Invalid setup key.', 403);
}
if (strpos((string)$CONFIG['setup_key'], 'CHANGE-ME') === 0) {
  json_error('Refusing to run: set a real setup_key in config.php first.', 400);
}
if (strpos((string)$CONFIG['superadmin_password'], 'CHANGE-ME') === 0 || strlen((string)$CONFIG['superadmin_password']) < 10) {
  json_error('Refusing to run: set a strong superadmin_password (10+ chars) in config.php first.', 400);
}

$pdo = db();
$username = (string)$CONFIG['superadmin_username'];
$hash = password_hash((string)$CONFIG['superadmin_password'], PASSWORD_BCRYPT);
$name = (string)($CONFIG['superadmin_name'] ?? 'Administrator');

$stmt = $pdo->prepare('SELECT id FROM users WHERE username = ?');
$stmt->execute([$username]);
$existing = $stmt->fetch();

if ($existing) {
  $pdo->prepare('UPDATE users SET password_hash = ?, display_name = ?, role = \'superadmin\', is_active = 1 WHERE id = ?')
      ->execute([$hash, $name, $existing['id']]);
  audit($username, 'superadmin', 'setup.superadmin_updated');
  json_out(['ok' => true, 'message' => "Superadmin '$username' password updated. Now delete setup.php from the server."]);
} else {
  $id = uuid4();
  $pdo->prepare('INSERT INTO users (id, username, password_hash, display_name, role) VALUES (?, ?, ?, ?, \'superadmin\')')
      ->execute([$id, $username, $hash, $name]);
  audit($username, 'superadmin', 'setup.superadmin_created');
  json_out(['ok' => true, 'message' => "Superadmin '$username' created. Now delete setup.php from the server."]);
}
