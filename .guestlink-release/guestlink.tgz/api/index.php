<?php
/**
 * Vows & Guests REST API — single-file router for cPanel/shared hosting.
 *
 * Routes (relative to /api/):
 *   POST   auth/login                  { username, password } -> { token, user }
 *   GET    auth/me                      -> current session user
 *   GET    events                       -> events visible to the session (with aggregates)
 *   POST   events                       -> create event (superadmin)
 *   PATCH  events/{id}                  -> update event fields (superadmin)
 *   POST   events/{id}/credentials      -> set new couple credentials (superadmin)
 *   DELETE events/{id}                  -> soft delete (superadmin)
 *   GET    events/{id}/stats            -> aggregate stats
 *   GET    events/{id}/guests           -> guest list
 *   POST   events/{id}/guests           -> add one guest { name, allowed_count }
 *   POST   events/{id}/guests/bulk      -> add many { guests: [...] }
 *   GET    events/{id}/recent-checkins  -> latest check-in log entries with guest names
 *   GET    events/{id}/card-design      -> saved invitation design for the event
 *   PATCH  events/{id}/card-design      -> save invitation design for the event
 *   GET    card-templates               -> reusable templates owned by this login
 *   POST   card-templates               -> save a reusable template
 *   DELETE card-templates/{id}          -> delete an owned reusable template
 *   PATCH  guests/{id}                  -> update guest
 *   DELETE guests/{id}                  -> soft delete guest
 *   GET    guests/{id}/logs             -> check-in history
 *   POST   checkin                      { guest_id, count, source? } (auth, atomic)
 *   GET    public/invite?token=...      -> guest + event by token or backup token (no auth)
 *   POST   public/rsvp                  { token, attending } (no auth)
 *   GET    event-types                  -> list
 *   POST   event-types                  { name } (superadmin)
 */

declare(strict_types=1);

require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/jwt.php';
require __DIR__ . '/lib/domain.php';
require __DIR__ . '/lib/schema.php';
require __DIR__ . '/lib/shop-auth.php';

$method = $_SERVER['REQUEST_METHOD'];
// Path from .htaccess rewrite (?r=) with PATH_INFO fallback.
$path = trim($_GET['r'] ?? ($_SERVER['PATH_INFO'] ?? ''), '/');
$segments = $path === '' ? [] : explode('/', $path);

try {
  // Self-heal the database schema on the first request after a deploy so that
  // scanner state, invitation designs, and templates persist without a manual
  // migration step. Idempotent and cheap after the first successful run.
  ensure_schema();
  route($method, $segments);
} catch (PDOException $e) {
  audit('system', 'system', 'error.db', null, $e->getMessage());
  json_error('A database error occurred.', 500);
} catch (Throwable $e) {
  audit('system', 'system', 'error.server', null, $e->getMessage());
  json_error('An unexpected server error occurred.', 500);
}

function route(string $method, array $seg): void {
  $s0 = $seg[0] ?? '';
  $s1 = $seg[1] ?? null;
  $s2 = $seg[2] ?? null;

  // ---------- AUTH ----------
  if ($s0 === 'auth' && $s1 === 'login' && $method === 'POST') { handle_login(); }
  if ($s0 === 'auth' && $s1 === 'shop' && $method === 'POST') { handle_shop_login(); }
  if ($s0 === 'auth' && $s1 === 'me' && $method === 'GET') {
    $session = require_auth();
    json_out(['user' => session_user($session)]);
  }

  // ---------- HEALTH (no auth; reports deploy + schema migration state) ----------
  if ($s0 === 'health' && $s1 === null && $method === 'GET') { handle_health(); }

  // ---------- PUBLIC (guest invite page + gate lookups) ----------
  if ($s0 === 'public' && $s1 === 'invite' && $method === 'GET') { handle_public_invite(); }
  if ($s0 === 'public' && $s1 === 'rsvp' && $method === 'POST') { handle_public_rsvp(); }

  // ---------- EVENT TYPES ----------
  if ($s0 === 'event-types' && $method === 'GET') {
    $rows = db()->query('SELECT name FROM event_types ORDER BY name ASC')->fetchAll();
    json_out(['types' => array_column($rows, 'name')]);
  }
  if ($s0 === 'event-types' && $method === 'POST') {
    $session = require_auth();
    require_superadmin($session);
    $body = read_json_body();
    $name = trim((string)($body['name'] ?? ''));
    if ($name === '' || mb_strlen($name) > 64) json_error('Event type name must be 1-64 characters.');
    db()->prepare('INSERT IGNORE INTO event_types (name) VALUES (?)')->execute([$name]);
    audit($session['name'] ?? 'admin', $session['role'], 'event_type.add', null, $name);
    json_out(['name' => $name], 201);
  }

  // ---------- EVENTS ----------
  if ($s0 === 'events' && $s1 === null && $method === 'GET') { handle_list_events(); }
  if ($s0 === 'events' && $s1 === null && $method === 'POST') { handle_create_event(); }
  if ($s0 === 'events' && $s1 !== null && $s2 === null && $method === 'PATCH') { handle_update_event($s1); }
  if ($s0 === 'events' && $s1 !== null && $s2 === null && $method === 'DELETE') { handle_delete_event($s1); }
  if ($s0 === 'events' && $s1 !== null && $s2 === 'credentials' && $method === 'POST') { handle_set_credentials($s1); }
  if ($s0 === 'events' && $s1 !== null && $s2 === 'stats' && $method === 'GET') { handle_event_stats($s1); }
  if ($s0 === 'events' && $s1 !== null && $s2 === 'guests' && $method === 'GET') { handle_list_guests($s1); }
  if ($s0 === 'events' && $s1 !== null && $s2 === 'guests' && $method === 'POST' && ($seg[3] ?? '') === '') { handle_add_guest($s1); }
  if ($s0 === 'events' && $s1 !== null && $s2 === 'guests' && ($seg[3] ?? '') === 'bulk' && $method === 'POST') { handle_add_guests_bulk($s1); }
  if ($s0 === 'events' && $s1 !== null && $s2 === 'recent-checkins' && $method === 'GET') { handle_recent_checkins($s1); }
  if ($s0 === 'events' && $s1 !== null && $s2 === 'card-design' && $method === 'GET') { handle_get_card_design($s1); }
  if ($s0 === 'events' && $s1 !== null && $s2 === 'card-design' && $method === 'PATCH') { handle_save_card_design($s1); }

  // ---------- SAVED DESIGNS + ASSETS ----------
  if ($s0 === 'card-designs' && $s1 === null && $method === 'GET') { handle_list_card_designs(); }
  if ($s0 === 'card-designs' && $s1 !== null && $s2 === null && $method === 'PATCH') { handle_update_card_design($s1); }
  if ($s0 === 'card-designs' && $s1 !== null && $s2 === null && $method === 'DELETE') { handle_delete_card_design($s1); }
  if ($s0 === 'card-designs' && $s1 !== null && $s2 === 'duplicate' && $method === 'POST') { handle_duplicate_card_design($s1); }
  if ($s0 === 'card-designs' && $s1 !== null && $s2 === 'activate' && $method === 'POST') { handle_activate_card_design($s1); }
  if ($s0 === 'design-assets' && $s1 === null && $method === 'POST') { handle_upload_design_asset(); }

  // ---------- INVITATION TEMPLATES ----------
  if ($s0 === 'card-templates' && $s1 === null && $method === 'GET') { handle_list_card_templates(); }
  if ($s0 === 'card-templates' && $s1 === null && $method === 'POST') { handle_create_card_template(); }
  if ($s0 === 'card-templates' && $s1 !== null && $s2 === null && $method === 'PATCH') { handle_update_card_template($s1); }
  if ($s0 === 'card-templates' && $s1 !== null && $method === 'DELETE') { handle_delete_card_template($s1); }
  if ($s0 === 'card-templates' && $s1 !== null && $s2 === 'duplicate' && $method === 'POST') { handle_duplicate_card_template($s1); }
  if ($s0 === 'card-templates' && $s1 !== null && $s2 === 'design' && $method === 'POST') { handle_create_design_from_template($s1); }

  // ---------- ADMIN TEMPLATE LIBRARY ----------
  if ($s0 === 'admin' && $s1 === 'card-designs' && $method === 'GET') { handle_list_card_designs(true); }
  if ($s0 === 'admin' && $s1 === 'public-templates' && $s2 === null && $method === 'POST') { handle_create_public_template(); }

  // ---------- GUESTS ----------
  if ($s0 === 'guests' && $s1 !== null && $s2 === null && $method === 'PATCH') { handle_update_guest($s1); }
  if ($s0 === 'guests' && $s1 !== null && $s2 === null && $method === 'DELETE') { handle_delete_guest($s1); }
  if ($s0 === 'guests' && $s1 !== null && $s2 === 'logs' && $method === 'GET') { handle_guest_logs($s1); }

  // ---------- CHECK-IN ----------
  if ($s0 === 'checkin' && $method === 'POST') { handle_checkin(); }

  json_error('Not found.', 404);
}

// ==========================================================
// Health / deploy probe
// ==========================================================

function handle_health(): void {
  // Reports only non-sensitive deploy signals: whether this build knows about
  // the current schema version and whether ensure_schema() has applied it.
  $migrated = false;
  $tables = [];
  try {
    $pdo = db();
    $migrated = (bool)$pdo->query(
      "SELECT 1 FROM schema_migrations WHERE id = '" . SCHEMA_VERSION . "' LIMIT 1"
    )->fetchColumn();
    foreach (['card_designs', 'card_templates', 'design_assets'] as $table) {
      $tables[$table] = (int)$pdo->query(
        "SELECT COUNT(*) FROM information_schema.tables
         WHERE table_schema = DATABASE() AND table_name = '$table'"
      )->fetchColumn() > 0;
    }
    $tables['events.scanner_enabled'] = (int)$pdo->query(
      "SELECT COUNT(*) FROM information_schema.columns
       WHERE table_schema = DATABASE() AND table_name = 'events' AND column_name = 'scanner_enabled'"
    )->fetchColumn() > 0;
  } catch (Throwable $e) {
    // Leave defaults; the endpoint itself still confirms the API is reachable.
  }
  json_out(['ok' => true, 'schema_version' => SCHEMA_VERSION, 'migrated' => $migrated, 'schema' => $tables]);
}

// ==========================================================
// Session helpers
// ==========================================================

function session_user(array $claims): array {
  return [
    'id'      => $claims['sub'],
    'role'    => $claims['role'] === 'superadmin' ? 'admin' : ($claims['role'] === 'member' ? 'member' : 'bride_groom'),
    'name'    => $claims['name'] ?? '',
    'eventId' => $claims['event_id'] ?? null,
    'email'   => $claims['username'] ?? '',
  ];
}

// ==========================================================
// AUTH
// ==========================================================

function handle_login(): void {
  if (!rate_limit_check('login', 10, 300)) {
    audit('anonymous', 'anonymous', 'login.rate_limited');
    json_error('Too many login attempts. Please wait 5 minutes and try again.', 429);
  }

  $body = read_json_body();
  $username = trim((string)($body['username'] ?? ''));
  $password = (string)($body['password'] ?? '');
  if ($username === '' || $password === '') json_error('Username and password are required.');

  $pdo = db();

  // 1. Admin users table
  $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND is_active = 1 AND role IN ('superadmin', 'admin') AND shop_user_id IS NULL");
  $stmt->execute([$username]);
  $user = $stmt->fetch();
  if ($user && password_verify($password, $user['password_hash'])) {
    audit($user['username'], $user['role'], 'login.success');
    $claims = [
      'sub' => $user['id'], 'role' => 'superadmin',
      'name' => $user['display_name'], 'username' => $user['username'],
    ];
    json_out(['token' => jwt_sign($claims), 'user' => session_user($claims)]);
  }

  // 2. Event access code (couple login)
  $stmt = $pdo->prepare('SELECT * FROM events WHERE access_code = ? AND is_deleted = 0');
  $stmt->execute([strtoupper($username)]);
  $event = $stmt->fetch();
  if ($event && password_verify($password, $event['password_hash'])) {
    audit($event['access_code'], 'event', 'login.success', $event['id']);
    $claims = [
      'sub' => 'event-' . $event['id'], 'role' => 'event',
      'name' => $event['name'], 'username' => $event['access_code'],
      'event_id' => $event['id'],
    ];
    json_out(['token' => jwt_sign($claims), 'user' => session_user($claims)]);
  }

  audit($username, 'anonymous', 'login.failed');
  json_error('Invalid credentials.', 401);
}

// ==========================================================
// EVENTS
// ==========================================================

function handle_list_events(): void {
  $session = require_auth();
  $pdo = db();

  // Both aggregates exclude declined guests so the check-in ratio stays
  // consistent (a guest who checked in some people and later declined must
  // not inflate the numerator while missing from the denominator).
  $agg = 'SELECT e.*,
            (SELECT COALESCE(SUM(g.allowed_count), 0) FROM guests g
              WHERE g.event_id = e.id AND g.is_deleted = 0 AND g.status != \'declined\') AS guests_count,
            (SELECT COALESCE(SUM(g.checked_in_count), 0) FROM guests g
              WHERE g.event_id = e.id AND g.is_deleted = 0 AND g.status != \'declined\') AS agg_checked_in
          FROM events e WHERE e.is_deleted = 0';

  if ($session['role'] === 'superadmin') {
    $rows = $pdo->query($agg . ' ORDER BY e.date ASC')->fetchAll();
  } elseif ($session['role'] === 'member') {
    $stmt = $pdo->prepare($agg . ' AND e.user_id = ? ORDER BY e.date ASC');
    $stmt->execute([$session['sub']]);
    $rows = $stmt->fetchAll();
  } else {
    $stmt = $pdo->prepare($agg . ' AND e.id = ?');
    $stmt->execute([$session['event_id']]);
    $rows = $stmt->fetchAll();
  }
  json_out(['events' => array_map('shape_event', $rows)]);
}

function handle_create_event(): void {
  $session = require_auth();
  require_event_manager($session);
  $body = read_json_body();

  $name = trim((string)($body['name'] ?? ''));
  $date = trim((string)($body['date'] ?? ''));
  $venue = trim((string)($body['venue'] ?? ''));
  if ($name === '' || $venue === '') json_error('Event name and venue are required.');
  if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) json_error('Event date must be YYYY-MM-DD.');

  $guestLimit = (int)($body['guest_limit'] ?? 300);
  if ($guestLimit < 1 || $guestLimit > 100000) json_error('Guest limit must be between 1 and 100000.');

  $accessCode = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string)($body['access_code'] ?? '')));
  $password = (string)($body['password'] ?? '');
  if ($accessCode === '') $accessCode = generate_access_code();
  if ($password === '') $password = generate_access_code(10);
  if (strlen($password) < 6) json_error('Couple password must be at least 6 characters.');

  $pdo = db();
  $id = uuid4();

  // Retry once on access-code collision instead of failing the request.
  for ($attempt = 0; $attempt < 3; $attempt++) {
    try {
      $stmt = $pdo->prepare(
        'INSERT INTO events (id, user_id, name, date, venue, notes, access_code, password_hash,
                             guest_limit, rsvp_enabled, services_paused)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)'
      );
      $stmt->execute([
        $id, $session['sub'], $name, $date, $venue,
        (string)($body['notes'] ?? ''), $accessCode,
        password_hash($password, PASSWORD_BCRYPT),
        $guestLimit, !empty($body['rsvp_enabled']) ? 1 : 0,
      ]);
      break;
    } catch (PDOException $e) {
      if ($e->getCode() === '23000' && $attempt < 2 && empty($body['access_code'])) {
        $accessCode = generate_access_code(); // collision on random code -> regenerate
        continue;
      }
      if ($e->getCode() === '23000') json_error('That access code is already used by another event.');
      throw $e;
    }
  }

  audit($session['name'], $session['role'], 'event.create', $id, $name);
  $row = fetch_event_or_404($id);
  $shaped = shape_event($row);
  // Plaintext password is returned exactly once so the admin can hand it over.
  $shaped['initial_password'] = $password;
  json_out(['event' => $shaped], 201);
}

function handle_update_event(string $eventId): void {
  $session = require_auth();
  require_event_manager($session, $eventId);
  fetch_event_or_404($eventId);
  $body = read_json_body();

  $allowed = ['name', 'date', 'venue', 'notes', 'guest_limit', 'rsvp_enabled', 'services_paused', 'scanner_enabled'];
  if (array_key_exists('services_paused', $body)) require_superadmin($session);
  $sets = [];
  $params = [];
  foreach ($allowed as $field) {
    if (!array_key_exists($field, $body)) continue;
    $value = $body[$field];
    if ($field === 'guest_limit') {
      $value = (int)$value;
      if ($value < 1 || $value > 100000) json_error('Guest limit must be between 1 and 100000.');
    }
    // scanner_enabled accepts null ("auto") as well as a saved true/false override.
    if ($field === 'scanner_enabled') $value = $value === null ? null : ($value ? 1 : 0);
    if ($field === 'rsvp_enabled' || $field === 'services_paused') $value = $value ? 1 : 0;
    if ($field === 'date' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$value)) json_error('Event date must be YYYY-MM-DD.');
    $sets[] = "`$field` = ?";
    $params[] = $value;
  }
  if (!$sets) json_error('No valid fields to update.');
  $params[] = $eventId;
  db()->prepare('UPDATE events SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($params);

  audit($session['name'], $session['role'], 'event.update', $eventId, implode(',', array_keys($body)));
  json_out(['event' => shape_event(fetch_event_or_404($eventId))]);
}

function handle_set_credentials(string $eventId): void {
  $session = require_auth();
  require_event_manager($session, $eventId);
  fetch_event_or_404($eventId);
  $body = read_json_body();

  $accessCode = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string)($body['access_code'] ?? '')));
  $password = (string)($body['password'] ?? '');
  if ($accessCode === '') json_error('Access code is required.');
  // Empty password means "keep the current one" — only the username changes.
  if ($password !== '' && strlen($password) < 6) json_error('Password must be at least 6 characters.');

  try {
    if ($password !== '') {
      db()->prepare('UPDATE events SET access_code = ?, password_hash = ? WHERE id = ?')
          ->execute([$accessCode, password_hash($password, PASSWORD_BCRYPT), $eventId]);
    } else {
      db()->prepare('UPDATE events SET access_code = ? WHERE id = ?')
          ->execute([$accessCode, $eventId]);
    }
  } catch (PDOException $e) {
    if ($e->getCode() === '23000') json_error('That access code is already used by another event.');
    throw $e;
  }

  audit($session['name'], $session['role'], 'event.credentials_changed', $eventId);
  json_out(['ok' => true, 'access_code' => $accessCode]);
}

function handle_delete_event(string $eventId): void {
  $session = require_auth();
  require_event_manager($session, $eventId);
  fetch_event_or_404($eventId);
  db()->prepare('UPDATE events SET is_deleted = 1 WHERE id = ?')->execute([$eventId]);
  audit($session['name'], $session['role'], 'event.delete', $eventId);
  json_out(['ok' => true]);
}

function handle_event_stats(string $eventId): void {
  $session = require_auth();
  require_event_access($session, $eventId);
  fetch_event_or_404($eventId);

  $stmt = db()->prepare(
    "SELECT
       COALESCE(SUM(CASE WHEN status != 'declined' THEN allowed_count ELSE 0 END), 0) AS invited,
       COUNT(*) AS groups_total,
       COALESCE(SUM(CASE WHEN status != 'declined' THEN checked_in_count ELSE 0 END), 0) AS checked_in,
       COALESCE(SUM(CASE WHEN status = 'declined' THEN 1 ELSE 0 END), 0) AS declined
     FROM guests WHERE event_id = ? AND is_deleted = 0"
  );
  $stmt->execute([$eventId]);
  $row = $stmt->fetch();

  json_out(['stats' => [
    'totalInvitedPeople' => (int)$row['invited'],
    'totalGuestsGroups'  => (int)$row['groups_total'],
    'checkedInPeople'    => (int)$row['checked_in'],
    'remainingPeople'    => (int)$row['invited'] - (int)$row['checked_in'],
    'notAttendingCount'  => (int)$row['declined'],
  ]]);
}

// ==========================================================
// INVITATION DESIGNS + REUSABLE TEMPLATES
// ==========================================================

function validated_card_template(array $body): array {
  $template = $body['template'] ?? null;
  if (!is_array($template) || ($template['version'] ?? null) !== 1 || !is_array($template['elements'] ?? null)) {
    json_error('A valid version 1 card template is required.');
  }
  if (count($template['elements']) > 250) json_error('A design can contain at most 250 elements.');
  foreach ($template['elements'] as $element) {
    if (($element['role'] ?? '') === 'image' && isset($element['src']) && str_starts_with((string)$element['src'], 'data:')) {
      json_error('Upload all design images before saving.', 422);
    }
  }
  $json = json_encode($template, JSON_UNESCAPED_SLASHES);
  if ($json === false || strlen($json) > 4 * 1024 * 1024) {
    json_error('The design is too large to save. Use smaller uploaded images.', 413);
  }
  return [$template, $json];
}

function template_owner_key(array $session): string {
  if (($session['role'] ?? '') === 'event') return 'event:' . (string)$session['event_id'];
  return 'user:' . (string)$session['sub'];
}

function event_design_owner_key(string $eventId): string {
  return 'event:' . $eventId;
}

function shape_card_design(array $row): array {
  $template = json_decode((string)$row['template_json'], true);
  return [
    'id' => $row['id'],
    'event_id' => $row['event_id'],
    'owner_key' => $row['owner_key'],
    'owner_name' => $row['owner_name'] ?? null,
    'name' => $row['name'],
    'template' => is_array($template) ? $template : null,
    'version' => (int)$row['version'],
    'is_active' => (bool)$row['is_active'],
    'created_at' => $row['created_at'],
    'updated_at' => $row['updated_at'],
  ];
}

function require_design_access(array $session, array $design): void {
  if (($session['role'] ?? '') === 'superadmin') return;
  if (($session['role'] ?? '') === 'member' && !empty($design['event_id'])) {
    require_event_access($session, (string)$design['event_id']);
    return;
  }
  if (($design['owner_key'] ?? '') === template_owner_key($session)) return;
  json_error('You do not have access to this design.', 403);
}

function fetch_card_design_or_404(string $designId): array {
  $stmt = db()->prepare('SELECT * FROM card_designs WHERE id = ?');
  $stmt->execute([$designId]);
  $row = $stmt->fetch();
  if (!$row) json_error('Design not found.', 404);
  return $row;
}

function clone_template_ids(array $template): array {
  foreach ($template['elements'] as $index => $element) {
    $prefix = preg_replace('/[^a-z0-9_-]/i', '', (string)($element['role'] ?? 'el')) ?: 'el';
    $template['elements'][$index]['id'] = $prefix . '_' . str_replace('-', '', uuid4());
  }
  return $template;
}

function create_card_design_record(array $session, string $eventId, string $name, array $template, bool $active): array {
  require_event_access($session, $eventId);
  fetch_event_or_404($eventId);
  [, $json] = validated_card_template(['template' => $template]);
  $id = uuid4();
  $pdo = db();
  $pdo->beginTransaction();
  try {
    if ($active) $pdo->prepare('UPDATE card_designs SET is_active = 0 WHERE event_id = ?')->execute([$eventId]);
    $pdo->prepare('INSERT INTO card_designs (id, owner_key, event_id, name, template_json, version, is_active, created_by) VALUES (?, ?, ?, ?, ?, 1, ?, ?)')
      ->execute([$id, event_design_owner_key($eventId), $eventId, $name, $json, $active ? 1 : 0, (string)$session['sub']]);
    $pdo->commit();
  } catch (Throwable $error) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $error;
  }
  return fetch_card_design_or_404($id);
}

function handle_get_card_design(string $eventId): void {
  $session = require_auth();
  require_event_access($session, $eventId);
  fetch_event_or_404($eventId);
  $stmt = db()->prepare('SELECT * FROM card_designs WHERE event_id = ? AND is_active = 1 ORDER BY updated_at DESC LIMIT 1');
  $stmt->execute([$eventId]);
  $row = $stmt->fetch();
  if (!$row) json_out(['design' => null]);
  json_out(['design' => shape_card_design($row)]);
}

function handle_save_card_design(string $eventId): void {
  $session = require_auth();
  require_event_access($session, $eventId);
  fetch_event_or_404($eventId);
  $body = read_json_body();
  [$template, $json] = validated_card_template($body);
  $stmt = db()->prepare('SELECT * FROM card_designs WHERE event_id = ? AND is_active = 1 ORDER BY updated_at DESC LIMIT 1');
  $stmt->execute([$eventId]);
  $current = $stmt->fetch();
  if (!$current) {
    $current = create_card_design_record($session, $eventId, trim((string)($body['name'] ?? 'Invitation design')) ?: 'Invitation design', $template, true);
  } else {
    $expected = isset($body['expected_version']) ? (int)$body['expected_version'] : null;
    if ($expected !== null && $expected !== (int)$current['version']) {
      json_error('This design was updated on another device. Reload it before saving again.', 409);
    }
    db()->prepare('UPDATE card_designs SET template_json = ?, version = version + 1, created_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      ->execute([$json, (string)$session['sub'], $current['id']]);
    $current = fetch_card_design_or_404((string)$current['id']);
  }
  audit($session['name'] ?? 'user', $session['role'], 'card_design.save', $eventId);
  json_out(['design' => shape_card_design($current)]);
}

function handle_list_card_designs(bool $adminOnly = false): void {
  $session = require_auth();
  if ($adminOnly) require_superadmin($session);
  $search = trim((string)($_GET['search'] ?? ''));
  $eventId = trim((string)($_GET['event_id'] ?? ''));
  $params = [];
  $where = [];
  if (($session['role'] ?? '') === 'member') {
    $where[] = 'e.user_id = ? AND e.is_deleted = 0';
    $params[] = $session['sub'];
  } elseif (($session['role'] ?? '') !== 'superadmin') {
    $where[] = 'd.owner_key = ?';
    $params[] = template_owner_key($session);
  }
  if ($eventId !== '') {
    if (($session['role'] ?? '') !== 'superadmin') require_event_access($session, $eventId);
    $where[] = 'd.event_id = ?';
    $params[] = $eventId;
  }
  if ($search !== '') {
    $where[] = '(d.name LIKE ? OR e.name LIKE ?)';
    $params[] = '%' . $search . '%';
    $params[] = '%' . $search . '%';
  }
  $sql = 'SELECT d.*, e.name AS owner_name FROM card_designs d LEFT JOIN events e ON e.id = d.event_id';
  if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
  $sql .= ' ORDER BY d.updated_at DESC LIMIT 250';
  $stmt = db()->prepare($sql);
  $stmt->execute($params);
  json_out(['designs' => array_map('shape_card_design', $stmt->fetchAll())]);
}

function handle_update_card_design(string $designId): void {
  $session = require_auth();
  $design = fetch_card_design_or_404($designId);
  require_design_access($session, $design);
  if ($design['event_id']) require_event_access($session, (string)$design['event_id']);
  $body = read_json_body();
  $expected = isset($body['expected_version']) ? (int)$body['expected_version'] : null;
  if ($expected !== null && $expected !== (int)$design['version']) json_error('This design has a newer version.', 409);
  $sets = [];
  $params = [];
  if (array_key_exists('name', $body)) {
    $name = trim((string)$body['name']);
    if ($name === '' || mb_strlen($name) > 120) json_error('Design name must be 1-120 characters.');
    $sets[] = 'name = ?'; $params[] = $name;
  }
  if (array_key_exists('template', $body)) {
    [, $json] = validated_card_template($body);
    $sets[] = 'template_json = ?'; $params[] = $json;
  }
  if (!$sets) json_error('No design changes were provided.');
  $sets[] = 'version = version + 1';
  $sets[] = 'updated_at = CURRENT_TIMESTAMP';
  $params[] = $designId;
  db()->prepare('UPDATE card_designs SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($params);
  json_out(['design' => shape_card_design(fetch_card_design_or_404($designId))]);
}

function handle_duplicate_card_design(string $designId): void {
  $session = require_auth();
  $design = fetch_card_design_or_404($designId);
  require_design_access($session, $design);
  $template = clone_template_ids(json_decode((string)$design['template_json'], true));
  $copy = create_card_design_record($session, (string)$design['event_id'], (string)$design['name'] . ' copy', $template, false);
  json_out(['design' => shape_card_design($copy)], 201);
}

function handle_activate_card_design(string $designId): void {
  $session = require_auth();
  $design = fetch_card_design_or_404($designId);
  require_design_access($session, $design);
  require_event_access($session, (string)$design['event_id']);
  $pdo = db();
  $pdo->beginTransaction();
  try {
    $pdo->prepare('UPDATE card_designs SET is_active = 0 WHERE event_id = ?')->execute([$design['event_id']]);
    $pdo->prepare('UPDATE card_designs SET is_active = 1 WHERE id = ?')->execute([$designId]);
    $pdo->commit();
  } catch (Throwable $error) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $error;
  }
  json_out(['design' => shape_card_design(fetch_card_design_or_404($designId))]);
}

function handle_delete_card_design(string $designId): void {
  $session = require_auth();
  $design = fetch_card_design_or_404($designId);
  require_design_access($session, $design);
  if ($design['event_id']) require_event_access($session, (string)$design['event_id']);
  db()->prepare('DELETE FROM card_designs WHERE id = ?')->execute([$designId]);
  if (!empty($design['is_active']) && $design['event_id']) {
    db()->prepare('UPDATE card_designs SET is_active = 1 WHERE event_id = ? ORDER BY updated_at DESC LIMIT 1')->execute([$design['event_id']]);
  }
  audit($session['name'] ?? 'user', $session['role'], 'card_design.delete', $designId);
  json_out(['ok' => true]);
}

function handle_upload_design_asset(): void {
  $session = require_auth();
  if (!isset($_FILES['asset']) || !is_uploaded_file($_FILES['asset']['tmp_name'])) json_error('Choose an image to upload.');
  $file = $_FILES['asset'];
  if ((int)$file['error'] !== UPLOAD_ERR_OK) json_error('The image upload failed.', 422);
  if ((int)$file['size'] > 12 * 1024 * 1024) json_error('Images must be 12 MB or smaller.', 413);
  $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
  $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
  if (!isset($extensions[$mime])) json_error('Only JPG, PNG, and WebP images are supported.', 415);
  $id = uuid4();
  $ownerKey = template_owner_key($session);
  $ownerFolder = substr(hash('sha256', $ownerKey), 0, 20);
  $relative = 'uploads/design-assets/' . $ownerFolder . '/' . $id . '.' . $extensions[$mime];
  $absolute = dirname(__DIR__) . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
  $directory = dirname($absolute);
  if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) json_error('Asset storage is unavailable.', 500);
  if (!move_uploaded_file($file['tmp_name'], $absolute)) json_error('The image could not be stored.', 500);
  $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
  $host = $_SERVER['HTTP_HOST'] ?? '';
  $appBase = rtrim(dirname(dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/api/index.php'))), '/\\');
  $urlPath = ($appBase === '' ? '' : $appBase) . '/' . $relative;
  $url = $host !== '' ? $scheme . '://' . $host . $urlPath : $urlPath;
  db()->prepare('INSERT INTO design_assets (id, owner_key, storage_path, public_url, mime_type, byte_size) VALUES (?, ?, ?, ?, ?, ?)')
    ->execute([$id, $ownerKey, $relative, $url, $mime, (int)$file['size']]);
  json_out(['asset' => ['id' => $id, 'url' => $url, 'mime_type' => $mime, 'byte_size' => (int)$file['size']]], 201);
}

function handle_list_card_templates(): void {
  $session = require_auth();
  $ownerKey = template_owner_key($session);
  if (($session['role'] ?? '') === 'superadmin') {
    $stmt = db()->prepare("SELECT * FROM card_templates WHERE owner_key = ? OR scope = 'public' ORDER BY updated_at DESC");
    $stmt->execute([$ownerKey]);
  } else {
    $stmt = db()->prepare("SELECT * FROM card_templates WHERE owner_key = ? OR (scope = 'public' AND is_published = 1) ORDER BY scope ASC, updated_at DESC");
    $stmt->execute([$ownerKey]);
  }
  $templates = [];
  foreach ($stmt->fetchAll() as $row) {
    $template = json_decode((string)$row['template_json'], true);
    if (!is_array($template)) continue;
    $templates[] = [
      'id' => $row['id'], 'name' => $row['name'], 'template' => $template,
      'kind' => $row['scope'], 'category' => $row['category'], 'published' => (bool)$row['is_published'],
      'created_at' => $row['created_at'], 'updated_at' => $row['updated_at'],
    ];
  }
  json_out(['templates' => $templates]);
}

function handle_create_card_template(): void {
  $session = require_auth();
  $body = read_json_body();
  $name = trim((string)($body['name'] ?? ''));
  if ($name === '' || mb_strlen($name) > 80) json_error('Template name must be 1-80 characters.');
  [, $json] = validated_card_template($body);
  $id = uuid4();
  db()->prepare("INSERT INTO card_templates (id, owner_key, name, template_json, scope, is_published, version) VALUES (?, ?, ?, ?, 'personal', 0, 1)")
      ->execute([$id, template_owner_key($session), $name, $json]);
  audit($session['name'] ?? 'user', $session['role'], 'card_template.create', $id, $name);
  json_out(['template' => [
    'id' => $id, 'name' => $name, 'template' => $body['template'], 'kind' => 'personal', 'published' => false,
    'created_at' => gmdate('c'), 'updated_at' => gmdate('c'),
  ]], 201);
}

function handle_delete_card_template(string $templateId): void {
  $session = require_auth();
  if (($session['role'] ?? '') === 'superadmin') {
    $stmt = db()->prepare("DELETE FROM card_templates WHERE id = ? AND (owner_key = ? OR scope = 'public')");
  } else {
    $stmt = db()->prepare("DELETE FROM card_templates WHERE id = ? AND owner_key = ? AND scope = 'personal'");
  }
  $stmt->execute([$templateId, template_owner_key($session)]);
  if ($stmt->rowCount() === 0) json_error('Template not found.', 404);
  audit($session['name'] ?? 'user', $session['role'], 'card_template.delete', $templateId);
  json_out(['ok' => true]);
}

function fetch_template_for_session(string $templateId, array $session, bool $allowUnpublishedForAdmin = true): array {
  $stmt = db()->prepare('SELECT * FROM card_templates WHERE id = ?');
  $stmt->execute([$templateId]);
  $row = $stmt->fetch();
  if (!$row) json_error('Template not found.', 404);
  $isOwner = $row['owner_key'] === template_owner_key($session) && $row['scope'] === 'personal';
  $isPublic = $row['scope'] === 'public' && (!empty($row['is_published']) || ($allowUnpublishedForAdmin && ($session['role'] ?? '') === 'superadmin'));
  if (!$isOwner && !$isPublic) json_error('You do not have access to this template.', 403);
  return $row;
}

function shape_card_template(array $row): array {
  return [
    'id' => $row['id'], 'name' => $row['name'],
    'template' => json_decode((string)$row['template_json'], true),
    'kind' => $row['scope'], 'category' => $row['category'],
    'published' => (bool)$row['is_published'], 'version' => (int)$row['version'],
    'created_at' => $row['created_at'], 'updated_at' => $row['updated_at'],
  ];
}

function handle_update_card_template(string $templateId): void {
  $session = require_auth();
  $template = fetch_template_for_session($templateId, $session);
  if ($template['scope'] === 'public') require_superadmin($session);
  if ($template['scope'] === 'personal' && $template['owner_key'] !== template_owner_key($session)) json_error('You do not own this template.', 403);
  $body = read_json_body();
  if (isset($body['expected_version']) && (int)$body['expected_version'] !== (int)$template['version']) json_error('This template has a newer version.', 409);
  $sets = [];
  $params = [];
  if (array_key_exists('name', $body)) {
    $name = trim((string)$body['name']);
    if ($name === '' || mb_strlen($name) > 80) json_error('Template name must be 1-80 characters.');
    $sets[] = 'name = ?'; $params[] = $name;
  }
  if (array_key_exists('category', $body)) {
    $category = trim((string)$body['category']);
    if (mb_strlen($category) > 80) json_error('Category must be 80 characters or fewer.');
    $sets[] = 'category = ?'; $params[] = $category;
  }
  if (array_key_exists('published', $body)) {
    require_superadmin($session);
    if ($template['scope'] !== 'public') json_error('Only public templates can be published.');
    $sets[] = 'is_published = ?'; $params[] = !empty($body['published']) ? 1 : 0;
  }
  if (array_key_exists('template', $body)) {
    [, $json] = validated_card_template($body);
    $sets[] = 'template_json = ?'; $params[] = $json;
  }
  if (!$sets) json_error('No template changes were provided.');
  $sets[] = 'version = version + 1';
  $sets[] = 'updated_at = CURRENT_TIMESTAMP';
  $params[] = $templateId;
  db()->prepare('UPDATE card_templates SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($params);
  $stmt = db()->prepare('SELECT * FROM card_templates WHERE id = ?');
  $stmt->execute([$templateId]);
  json_out(['template' => shape_card_template($stmt->fetch())]);
}

function handle_duplicate_card_template(string $templateId): void {
  $session = require_auth();
  $source = fetch_template_for_session($templateId, $session);
  $template = clone_template_ids(json_decode((string)$source['template_json'], true));
  [, $json] = validated_card_template(['template' => $template]);
  $id = uuid4();
  db()->prepare("INSERT INTO card_templates (id, owner_key, name, template_json, scope, category, is_published, version) VALUES (?, ?, ?, ?, 'personal', ?, 0, 1)")
    ->execute([$id, template_owner_key($session), $source['name'] . ' copy', $json, $source['category']]);
  $stmt = db()->prepare('SELECT * FROM card_templates WHERE id = ?');
  $stmt->execute([$id]);
  json_out(['template' => shape_card_template($stmt->fetch())], 201);
}

function handle_create_design_from_template(string $templateId): void {
  $session = require_auth();
  $source = fetch_template_for_session($templateId, $session);
  $body = read_json_body();
  $eventId = trim((string)($body['event_id'] ?? ''));
  if ($eventId === '') json_error('An event is required.');
  $template = clone_template_ids(json_decode((string)$source['template_json'], true));
  $design = create_card_design_record($session, $eventId, (string)$source['name'], $template, true);
  audit($session['name'] ?? 'user', $session['role'], 'card_template.use', $templateId, $design['id']);
  json_out(['design' => shape_card_design($design)], 201);
}

function handle_create_public_template(): void {
  $session = require_auth();
  require_superadmin($session);
  $body = read_json_body();
  $designId = trim((string)($body['design_id'] ?? ''));
  $design = fetch_card_design_or_404($designId);
  $name = trim((string)($body['name'] ?? $design['name']));
  $category = trim((string)($body['category'] ?? ''));
  if ($name === '' || mb_strlen($name) > 80) json_error('Template name must be 1-80 characters.');
  if (mb_strlen($category) > 80) json_error('Category must be 80 characters or fewer.');
  $template = clone_template_ids(json_decode((string)$design['template_json'], true));
  [, $json] = validated_card_template(['template' => $template]);
  $id = uuid4();
  db()->prepare("INSERT INTO card_templates (id, owner_key, name, template_json, scope, category, is_published, source_design_id, version, managed_by) VALUES (?, ?, ?, ?, 'public', ?, ?, ?, 1, ?)")
    ->execute([$id, template_owner_key($session), $name, $json, $category, !empty($body['published']) ? 1 : 0, $designId, (string)$session['sub']]);
  $stmt = db()->prepare('SELECT * FROM card_templates WHERE id = ?');
  $stmt->execute([$id]);
  audit($session['name'] ?? 'admin', $session['role'], 'public_template.create', $id, $designId);
  json_out(['template' => shape_card_template($stmt->fetch())], 201);
}

// ==========================================================
// GUESTS
// ==========================================================

function handle_list_guests(string $eventId): void {
  $session = require_auth();
  require_event_access($session, $eventId);
  $stmt = db()->prepare('SELECT * FROM guests WHERE event_id = ? AND is_deleted = 0 ORDER BY name ASC');
  $stmt->execute([$eventId]);
  json_out(['guests' => array_map('shape_guest', $stmt->fetchAll())]);
}

function validate_guest_input(array $body): array {
  $name = trim((string)($body['name'] ?? ''));
  $allowed = (int)($body['allowed_count'] ?? 0);
  if ($name === '' || mb_strlen($name) > 255) json_error('Guest name must be 1-255 characters.');
  if ($allowed < 1 || $allowed > 1000) json_error('Allowed count must be between 1 and 1000.');
  return [$name, $allowed];
}

function ensure_not_paused(array $event, array $session): void {
  if (!empty($event['services_paused']) && $session['role'] !== 'superadmin') {
    json_error('This event is currently paused by the administrator. Operations are disabled.', 423);
  }
}

function insert_guest(PDO $pdo, string $eventId, string $name, int $allowed): array {
  $id = uuid4();
  $stmt = $pdo->prepare(
    'INSERT INTO guests (id, event_id, name, allowed_count, checked_in_count, status, token, backup_token)
     VALUES (?, ?, ?, ?, 0, \'pending\', ?, ?)'
  );
  // Retry backup token on the rare per-event collision.
  for ($attempt = 0; $attempt < 5; $attempt++) {
    try {
      $stmt->execute([$id, $eventId, $name, $allowed, generate_guest_token(), generate_backup_token()]);
      return fetch_guest_or_404($id);
    } catch (PDOException $e) {
      if ($e->getCode() !== '23000' || $attempt === 4) throw $e;
    }
  }
  throw new RuntimeException('unreachable');
}

function handle_add_guest(string $eventId): void {
  $session = require_auth();
  require_event_access($session, $eventId);
  $event = fetch_event_or_404($eventId);
  ensure_not_paused($event, $session);
  [$name, $allowed] = validate_guest_input(read_json_body());

  $pdo = db();
  $pdo->beginTransaction();
  try {
    $current = allocated_seats($pdo, $eventId);
    if ($current + $allowed > (int)$event['guest_limit']) {
      $pdo->rollBack();
      json_error("Exceeds capacity! Event limit is {$event['guest_limit']} seats and {$current} are already allocated.", 409);
    }
    $guest = insert_guest($pdo, $eventId, $name, $allowed);
    $pdo->commit();
  } catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
  }

  audit($session['name'], $session['role'], 'guest.add', $guest['id'], $name);
  json_out(['guest' => shape_guest($guest)], 201);
}

function handle_add_guests_bulk(string $eventId): void {
  $session = require_auth();
  require_event_access($session, $eventId);
  $event = fetch_event_or_404($eventId);
  ensure_not_paused($event, $session);

  $body = read_json_body();
  $list = $body['guests'] ?? [];
  if (!is_array($list) || count($list) === 0) json_error('Guest list is empty.');
  if (count($list) > 2000) json_error('Bulk import is limited to 2000 rows per upload.');

  $validated = [];
  $totalRequested = 0;
  foreach ($list as $entry) {
    [$name, $allowed] = validate_guest_input(is_array($entry) ? $entry : []);
    $validated[] = [$name, $allowed];
    $totalRequested += $allowed;
  }

  $pdo = db();
  $pdo->beginTransaction();
  try {
    $current = allocated_seats($pdo, $eventId);
    if ($current + $totalRequested > (int)$event['guest_limit']) {
      $pdo->rollBack();
      json_error("Exceeds capacity! Import needs {$totalRequested} seats but only " .
        max(0, (int)$event['guest_limit'] - $current) . ' remain.', 409);
    }
    foreach ($validated as [$name, $allowed]) {
      insert_guest($pdo, $eventId, $name, $allowed);
    }
    $pdo->commit();
  } catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
  }

  audit($session['name'], $session['role'], 'guest.bulk_add', $eventId, count($validated) . ' guests');
  json_out(['ok' => true, 'added' => count($validated)], 201);
}

function handle_update_guest(string $guestId): void {
  $session = require_auth();
  $guest = fetch_guest_or_404($guestId);
  require_event_access($session, $guest['event_id']);
  $event = fetch_event_or_404($guest['event_id']);
  ensure_not_paused($event, $session);

  $body = read_json_body();

  $name = array_key_exists('name', $body) ? trim((string)$body['name']) : $guest['name'];
  if ($name === '' || mb_strlen($name) > 255) json_error('Guest name must be 1-255 characters.');

  $allowed = array_key_exists('allowed_count', $body) ? (int)$body['allowed_count'] : (int)$guest['allowed_count'];
  if ($allowed < 1 || $allowed > 1000) json_error('Allowed count must be between 1 and 1000.');

  $checkedIn = array_key_exists('checked_in_count', $body) ? (int)$body['checked_in_count'] : (int)$guest['checked_in_count'];
  if ($checkedIn < 0 || $checkedIn > $allowed) json_error('Checked-in count cannot exceed allowed seats.');

  $status = array_key_exists('status', $body) ? (string)$body['status'] : $guest['status'];
  if (!in_array($status, ['pending', 'partial', 'completed', 'declined'], true)) json_error('Invalid status.');
  // Keep status coherent with counts unless explicitly declined.
  if ($status !== 'declined') $status = guest_status_for($checkedIn, $allowed, $status);

  $pdo = db();
  $pdo->beginTransaction();
  try {
    if ($allowed !== (int)$guest['allowed_count'] && $status !== 'declined') {
      $others = allocated_seats($pdo, $guest['event_id'], $guestId);
      if ($others + $allowed > (int)$event['guest_limit']) {
        $pdo->rollBack();
        json_error("Exceeds capacity! Event limit is {$event['guest_limit']} seats.", 409);
      }
    }
    $pdo->prepare('UPDATE guests SET name = ?, allowed_count = ?, checked_in_count = ?, status = ? WHERE id = ?')
        ->execute([$name, $allowed, $checkedIn, $status, $guestId]);
    $pdo->commit();
  } catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
  }

  audit($session['name'], $session['role'], 'guest.update', $guestId);
  json_out(['guest' => shape_guest(fetch_guest_or_404($guestId))]);
}

function handle_delete_guest(string $guestId): void {
  $session = require_auth();
  $guest = fetch_guest_or_404($guestId);
  require_event_access($session, $guest['event_id']);
  $event = fetch_event_or_404($guest['event_id']);
  ensure_not_paused($event, $session);

  db()->prepare('UPDATE guests SET is_deleted = 1 WHERE id = ?')->execute([$guestId]);
  audit($session['name'], $session['role'], 'guest.delete', $guestId, $guest['name']);
  json_out(['ok' => true]);
}

function handle_guest_logs(string $guestId): void {
  $session = require_auth();
  $guest = fetch_guest_or_404($guestId);
  require_event_access($session, $guest['event_id']);
  $stmt = db()->prepare('SELECT id, guest_id, count_arrived, created_at FROM check_in_logs WHERE guest_id = ? ORDER BY created_at DESC');
  $stmt->execute([$guestId]);
  json_out(['logs' => $stmt->fetchAll()]);
}

function handle_recent_checkins(string $eventId): void {
  $session = require_auth();
  require_event_access($session, $eventId);
  $stmt = db()->prepare(
    'SELECT l.id, l.count_arrived, l.created_at, g.name AS guest_name, g.status
     FROM check_in_logs l
     JOIN guests g ON g.id = l.guest_id
     WHERE g.event_id = ? AND g.is_deleted = 0
     ORDER BY l.created_at DESC
     LIMIT 20'
  );
  $stmt->execute([$eventId]);
  json_out(['checkins' => $stmt->fetchAll()]);
}

// ==========================================================
// CHECK-IN (atomic)
// ==========================================================

function handle_checkin(): void {
  $session = require_auth();
  $body = read_json_body();
  $guestId = (string)($body['guest_id'] ?? '');
  $count = (int)($body['count'] ?? 0);
  $source = ($body['source'] ?? 'online') === 'offline-sync' ? 'offline-sync' : 'online';
  if ($guestId === '') json_error('guest_id is required.');
  if ($count < 1 || $count > 1000) json_error('Arriving count must be at least 1.');

  $pdo = db();
  $pdo->beginTransaction();
  try {
    // Row lock prevents two gates checking in the same QR simultaneously.
    $stmt = $pdo->prepare('SELECT * FROM guests WHERE id = ? AND is_deleted = 0 FOR UPDATE');
    $stmt->execute([$guestId]);
    $guest = $stmt->fetch();
    if (!$guest) { $pdo->rollBack(); json_error('Guest record not found.', 404); }

    // Access + pause checks happen inside the transaction with fresh data.
    require_event_access($session, $guest['event_id']);
    $evtStmt = $pdo->prepare('SELECT * FROM events WHERE id = ? AND is_deleted = 0');
    $evtStmt->execute([$guest['event_id']]);
    $event = $evtStmt->fetch();
    if (!$event) { $pdo->rollBack(); json_error('Event not found.', 404); }
    if (!empty($event['services_paused']) && $session['role'] !== 'superadmin') {
      $pdo->rollBack();
      json_error('This event is currently paused by the administrator.', 423);
    }
    if ($guest['status'] === 'declined') {
      $pdo->rollBack();
      json_error('This guest declined the invitation (RSVP: not attending).', 409);
    }

    $newTotal = (int)$guest['checked_in_count'] + $count;
    if ($newTotal > (int)$guest['allowed_count']) {
      $remaining = (int)$guest['allowed_count'] - (int)$guest['checked_in_count'];
      $pdo->rollBack();
      json_error("Cannot check in {$count} people. Only {$remaining} seat(s) remain for this invitation.", 409);
    }

    $newStatus = guest_status_for($newTotal, (int)$guest['allowed_count'], $guest['status']);
    $pdo->prepare('UPDATE guests SET checked_in_count = ?, status = ? WHERE id = ?')
        ->execute([$newTotal, $newStatus, $guestId]);
    $pdo->prepare('INSERT INTO check_in_logs (id, guest_id, count_arrived, source) VALUES (?, ?, ?, ?)')
        ->execute([uuid4(), $guestId, $count, $source]);
    $pdo->commit();
  } catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
  }

  audit($session['name'], $session['role'], 'checkin.commit', $guestId, "+{$count} ({$source})");
  json_out(['guest' => shape_guest(fetch_guest_or_404($guestId))]);
}

// ==========================================================
// PUBLIC (invite page, no auth — token IS the credential)
// ==========================================================

function handle_public_invite(): void {
  // Generous per-IP window: an arrival rush on shared venue WiFi funnels
  // every guest's invite page (and the gate itself) through one public IP.
  if (!rate_limit_check('invite', 600, 60)) {
    json_error('Too many lookups. Please slow down.', 429);
  }
  $token = trim((string)($_GET['token'] ?? ''));
  if ($token === '' || mb_strlen($token) > 64) json_error('Invalid token.', 400);

  $pdo = db();
  // Primary hex token first, then the five-word backup token (case/space tolerant).
  $stmt = $pdo->prepare('SELECT * FROM guests WHERE token = ? AND is_deleted = 0');
  $stmt->execute([strtolower($token)]);
  $guest = $stmt->fetch();

  if (!$guest) {
    $normalized = strtoupper(preg_replace('/\s+/', ' ', $token));
    $stmt = $pdo->prepare('SELECT * FROM guests WHERE backup_token = ? AND is_deleted = 0');
    $stmt->execute([$normalized]);
    $guest = $stmt->fetch();
  }
  if (!$guest) json_error('No invitation matches this code.', 404);

  $stmt = $pdo->prepare('SELECT * FROM events WHERE id = ? AND is_deleted = 0');
  $stmt->execute([$guest['event_id']]);
  $event = $stmt->fetch();
  if (!$event) json_error('No invitation matches this code.', 404);

  json_out([
    'guest' => shape_guest($guest),
    'event' => shape_event_public($event),
  ]);
}

function handle_public_rsvp(): void {
  if (!rate_limit_check('rsvp', 20, 300)) {
    json_error('Too many RSVP updates. Please wait a few minutes.', 429);
  }
  $body = read_json_body();
  $token = trim((string)($body['token'] ?? ''));
  $attending = (bool)($body['attending'] ?? false);
  if ($token === '') json_error('Token is required.');

  $pdo = db();
  $stmt = $pdo->prepare('SELECT * FROM guests WHERE token = ? AND is_deleted = 0');
  $stmt->execute([strtolower($token)]);
  $guest = $stmt->fetch();
  if (!$guest) json_error('No invitation matches this code.', 404);

  $stmt = $pdo->prepare('SELECT * FROM events WHERE id = ? AND is_deleted = 0');
  $stmt->execute([$guest['event_id']]);
  $event = $stmt->fetch();
  if (!$event) json_error('No invitation matches this code.', 404);
  if (empty($event['rsvp_enabled'])) json_error('RSVP is disabled for this event.', 403);
  if (!empty($event['services_paused'])) json_error('This event is currently paused.', 423);

  if ($attending) {
    $status = guest_status_for((int)$guest['checked_in_count'], (int)$guest['allowed_count'], 'pending');
    $pdo->prepare('UPDATE guests SET status = ? WHERE id = ?')->execute([$status, $guest['id']]);
  } else {
    // Keep checked_in_count history intact; declined blocks future check-ins anyway.
    $pdo->prepare("UPDATE guests SET status = 'declined' WHERE id = ?")->execute([$guest['id']]);
  }

  audit($guest['name'], 'guest', $attending ? 'rsvp.attending' : 'rsvp.declined', $guest['id']);
  json_out(['ok' => true]);
}
