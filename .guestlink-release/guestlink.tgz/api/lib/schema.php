<?php
/**
 * Idempotent schema migrations for the invitation designer + gate-scanner
 * persistence. Shared by:
 *   - ensure_schema()  — runs automatically on the first API request after a
 *                        deploy, so a freshly deployed database self-heals.
 *   - migrate.php      — manual runner that reports each step (setup_key gated).
 *
 * Every statement is safe to run repeatedly. Adding a new migration: append a
 * statement here and bump SCHEMA_VERSION so ensure_schema() re-applies it.
 */

declare(strict_types=1);

const SCHEMA_VERSION = 'guestlink-2026-10-member-accounts';

/**
 * Apply all migrations. Per-statement try/catch so one failure never aborts the
 * rest. Returns [['label' => ..., 'ok' => bool, 'error' => ?string], ...].
 * Never throws.
 */
function run_schema_migrations(PDO $pdo): array {
  $results = [];

  $run = function (string $label, callable $fn) use (&$results): void {
    try {
      $fn();
      $results[] = ['label' => $label, 'ok' => true, 'error' => null];
    } catch (Throwable $e) {
      $results[] = ['label' => $label, 'ok' => false, 'error' => $e->getMessage()];
    }
  };

  // Member identities are distinct from existing administrator credentials.
  $run('member accounts', function () use ($pdo) {
    $pdo->exec("ALTER TABLE users MODIFY role ENUM('superadmin','admin','member') NOT NULL DEFAULT 'admin'");
    $exists = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.columns
      WHERE table_schema = DATABASE() AND table_name = 'users' AND column_name = 'shop_user_id'")->fetchColumn();
    if (!$exists) $pdo->exec('ALTER TABLE users ADD COLUMN shop_user_id VARCHAR(128) COLLATE utf8mb4_bin NULL UNIQUE');
  });

  // events.scanner_enabled — engine-agnostic add (works on MySQL and MariaDB).
  $run('events.scanner_enabled column', function () use ($pdo) {
    $exists = (int)$pdo->query(
      "SELECT COUNT(*) FROM information_schema.columns
       WHERE table_schema = DATABASE() AND table_name = 'events' AND column_name = 'scanner_enabled'"
    )->fetchColumn();
    if ($exists === 0) {
      $pdo->exec("ALTER TABLE events ADD COLUMN scanner_enabled TINYINT(1) NULL DEFAULT NULL AFTER services_paused");
    }
  });

  $run('event_card_designs table', function () use ($pdo) {
    $pdo->exec(
      "CREATE TABLE IF NOT EXISTS event_card_designs (
         event_id      CHAR(36)     NOT NULL PRIMARY KEY,
         template_json LONGTEXT     NOT NULL,
         updated_by    VARCHAR(72)  NOT NULL,
         created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
         updated_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
         CONSTRAINT fk_card_design_event FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
  });

  $run('card_designs table', function () use ($pdo) {
    $pdo->exec(
      "CREATE TABLE IF NOT EXISTS card_designs (
         id            CHAR(36)     NOT NULL PRIMARY KEY,
         owner_key     VARCHAR(80)  NOT NULL,
         event_id      CHAR(36)     NULL,
         name          VARCHAR(120) NOT NULL,
         template_json LONGTEXT     NOT NULL,
         version       INT UNSIGNED NOT NULL DEFAULT 1,
         is_active     TINYINT(1)   NOT NULL DEFAULT 0,
         created_by    VARCHAR(72)  NOT NULL,
         created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
         updated_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
         KEY idx_card_designs_owner (owner_key, updated_at),
         KEY idx_card_designs_event (event_id, is_active, updated_at),
         CONSTRAINT fk_saved_card_design_event FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
  });

  $run('design_assets table', function () use ($pdo) {
    $pdo->exec(
      "CREATE TABLE IF NOT EXISTS design_assets (
         id            CHAR(36)     NOT NULL PRIMARY KEY,
         owner_key     VARCHAR(80)  NOT NULL,
         storage_path  VARCHAR(255) NOT NULL,
         public_url    VARCHAR(500) NOT NULL,
         mime_type     VARCHAR(80)  NOT NULL,
         byte_size     INT UNSIGNED NOT NULL,
         created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
         KEY idx_design_assets_owner (owner_key, created_at)
       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
  });

  $run('card_templates table', function () use ($pdo) {
    $pdo->exec(
      "CREATE TABLE IF NOT EXISTS card_templates (
         id            CHAR(36)     NOT NULL PRIMARY KEY,
         owner_key     VARCHAR(80)  NOT NULL,
         name          VARCHAR(80)  NOT NULL,
         template_json LONGTEXT     NOT NULL,
         scope         ENUM('personal','public') NOT NULL DEFAULT 'personal',
         category      VARCHAR(80)   NOT NULL DEFAULT '',
         is_published  TINYINT(1)   NOT NULL DEFAULT 0,
         source_design_id CHAR(36)  NULL,
         version       INT UNSIGNED NOT NULL DEFAULT 1,
         managed_by    VARCHAR(72)  NULL,
         created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
         updated_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
         KEY idx_card_templates_owner (owner_key, updated_at),
         KEY idx_card_templates_public (scope, is_published, updated_at)
       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
  });

  // Upgrade an older card_templates table (pre public-template feature). Each
  // column is added only when missing so this works on MySQL and MariaDB.
  $templateColumns = [
    'scope'            => "ADD COLUMN scope ENUM('personal','public') NOT NULL DEFAULT 'personal' AFTER template_json",
    'category'         => "ADD COLUMN category VARCHAR(80) NOT NULL DEFAULT '' AFTER scope",
    'is_published'     => "ADD COLUMN is_published TINYINT(1) NOT NULL DEFAULT 0 AFTER category",
    'source_design_id' => "ADD COLUMN source_design_id CHAR(36) NULL AFTER is_published",
    'version'          => "ADD COLUMN version INT UNSIGNED NOT NULL DEFAULT 1 AFTER source_design_id",
    'managed_by'       => "ADD COLUMN managed_by VARCHAR(72) NULL AFTER version",
  ];
  foreach ($templateColumns as $column => $clause) {
    $run("card_templates.$column column", function () use ($pdo, $column, $clause) {
      $exists = (int)$pdo->query(
        "SELECT COUNT(*) FROM information_schema.columns
         WHERE table_schema = DATABASE() AND table_name = 'card_templates' AND column_name = '$column'"
      )->fetchColumn();
      if ($exists === 0) $pdo->exec("ALTER TABLE card_templates $clause");
    });
  }

  // Promote any legacy single-design rows into the versioned table so
  // previously saved invitation designs keep exporting.
  $run('legacy design backfill', function () use ($pdo) {
    $pdo->exec(
      "INSERT INTO card_designs (id, owner_key, event_id, name, template_json, version, is_active, created_by, created_at, updated_at)
       SELECT UUID(), CONCAT('event:', event_id), event_id, 'Invitation design', template_json, 1, 1, updated_by, created_at, updated_at
       FROM event_card_designs legacy
       WHERE NOT EXISTS (SELECT 1 FROM card_designs current_design WHERE current_design.event_id = legacy.event_id)"
    );
  });

  return $results;
}

/**
 * Auto-migrate on boot. Runs the migrations once per SCHEMA_VERSION, tracked in
 * a tiny schema_migrations table, so normal requests only pay one indexed
 * SELECT after the first successful run. Best-effort: never blocks a request.
 */
function ensure_schema(): void {
  static $done = false;
  if ($done) return;
  $done = true;

  $pdo = db();

  // Fast path: already applied.
  try {
    $applied = $pdo->query(
      "SELECT 1 FROM schema_migrations WHERE id = '" . SCHEMA_VERSION . "' LIMIT 1"
    )->fetchColumn();
    if ($applied) return;
  } catch (Throwable $e) {
    // schema_migrations doesn't exist yet — fall through and create everything.
  }

  try {
    $pdo->exec(
      "CREATE TABLE IF NOT EXISTS schema_migrations (
         id         VARCHAR(64) NOT NULL PRIMARY KEY,
         applied_at TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP
       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
    $results = run_schema_migrations($pdo);
    $allOk = array_reduce($results, fn($carry, $step) => $carry && $step['ok'], true);
    // Only record the version when everything applied, so a transient failure
    // is retried by a later request instead of being marked complete.
    if ($allOk) {
      $pdo->prepare("INSERT IGNORE INTO schema_migrations (id) VALUES (?)")->execute([SCHEMA_VERSION]);
    }
  } catch (Throwable $e) {
    // Leave it for the next request or the manual migrate.php runner.
  }
}
