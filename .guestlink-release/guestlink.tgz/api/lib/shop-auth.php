<?php
declare(strict_types=1);

/** Verify the existing shop session with its issuer; never trust client identity or roles. */
function verified_shop_user(string $token): array {
  if ($token === '' || strlen($token) > 8192 || !preg_match('/^[A-Za-z0-9_.-]+$/D', $token)) {
    json_error('Please sign in to your Mena account again.', 401);
  }
  if (!function_exists('curl_init')) json_error('Account sign-in is temporarily unavailable.', 503);
  // Fixed HTTPS destination: callers cannot redirect a bearer credential elsewhere.
  $ch = curl_init('https://menaincet.com/shop/api/auth/me');
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => false,
    CURLOPT_CONNECTTIMEOUT => 5,
    CURLOPT_TIMEOUT => 15,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_SSL_VERIFYHOST => 2,
    CURLOPT_HTTPHEADER => ['Accept: application/json', 'Authorization: Bearer ' . $token],
  ]);
  $raw = curl_exec($ch);
  $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  if ($status === 401 || $status === 403) json_error('Please sign in to your Mena account again.', 401);
  $data = is_string($raw) ? json_decode($raw, true) : null;
  $user = $data['user'] ?? null;
  if ($status !== 200 || !is_array($user) || !is_string($user['id'] ?? null) || $user['id'] === '' || strlen($user['id']) > 128) {
    json_error('Mena account verification is temporarily unavailable. Please try again.', 503);
  }
  return $user;
}

function handle_shop_login(): void {
  if (!rate_limit_check('shop-login', 30, 300)) json_error('Too many sign-in attempts. Please try again in 5 minutes.', 429);
  $body = read_json_body();
  $shop = verified_shop_user((string)($body['token'] ?? ''));
  $claims = shop_member_claims($shop);
  audit($claims['sub'], 'member', 'login.shop');
  header('Cache-Control: no-store');
  json_out(['token' => jwt_sign($claims), 'user' => session_user($claims)]);
}

/** Provision only an independently verified shop identity, always as a member. */
function shop_member_claims(array $shop): array {
  $pdo = db();
  // A separate identity link prevents matching an admin by email or username.
  // Even shop administrators receive only the member role in GuestLink.
  $name = mb_substr((string)($shop['name'] ?? 'Mena member'), 0, 128);
  $stmt = $pdo->prepare("INSERT INTO users (id, username, password_hash, display_name, role, shop_user_id)
    VALUES (?, ?, ?, ?, 'member', ?) ON DUPLICATE KEY UPDATE id = id");
  $stmt->execute([uuid4(), 'mena_' . substr(hash('sha256', $shop['id']), 0, 56),
    password_hash(bin2hex(random_bytes(32)), PASSWORD_BCRYPT), $name, $shop['id']]);
  $stmt = $pdo->prepare('SELECT * FROM users WHERE shop_user_id = ?');
  $stmt->execute([$shop['id']]);
  $user = $stmt->fetch();
  if (!$user || !$user['is_active'] || $user['role'] !== 'member') json_error('This account cannot access GuestLink.', 403);
  return ['sub' => $user['id'], 'role' => 'member', 'name' => $name,
    'username' => (string)($shop['email'] ?? $shop['identifier'] ?? '')];
}
