<?php
declare(strict_types=1);

/** Verify the existing shop session with its issuer; never trust client identity or roles. */
function verified_shop_user(string $token): array {
  if ($token === '' || strlen($token) > 8192 || !preg_match('/^[A-Za-z0-9_.-]+$/D', $token)) {
    json_error('Please sign in to your Mena account again.', 401);
  }
  if (!function_exists('curl_init')) json_error('Account sign-in is temporarily unavailable.', 503);
  // Fixed HTTPS destination: callers cannot redirect a bearer credential elsewhere.
  $ch = curl_init('https://menaincet.com/shop/api/auth/me');
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => false,
    CURLOPT_CONNECTTIMEOUT => 5,
    CURLOPT_TIMEOUT => 15,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_SSL_VERIFYHOST => 2,
    CURLOPT_HTTPHEADER => ['Accept: application/json', 'Authorization: Bearer ' . $token],
  ]);
  $raw = curl_exec($ch);
  $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  if ($status === 401 || $status === 403) json_error('Please sign in to your Mena account again.', 401);
  $data = is_string($raw) ? json_decode($raw, true) : null;
  $user = $data['user'] ?? null;
  if ($status !== 200 || !is_array($user) || !is_string($user['id'] ?? null) || $user['id'] === '' || strlen($user['id']) > 128) {
    json_error('Mena account verification is temporarily unavailable. Please try again.', 503);
  }
  return $user;
}

function handle_shop_login(): void {
  if (!rate_limit_check('shop-login', 30, 300)) json_error('Too many sign-in attempts. Please try again in 5 minutes.', 429);
  $body = read_json_body();
  $shop = verified_shop_user((string)($body['token'] ?? ''));
  $claims = shop_member_claims($shop);
  audit($claims['sub'], $claims['role'], 'login.shop');
  header('Cache-Control: no-store');
  json_out(['token' => jwt_sign($claims), 'user' => session_user($claims)]);
}

/**
 * Resolve an independently verified shop identity. The one active super-admin
 * may use the same email on the shared Mena login screen; every other shop
 * identity remains a strictly scoped GuestLink member.
 */
function shop_member_claims(array $shop): array {
  $pdo = db();
  $name = mb_substr((string)($shop['name'] ?? 'Mena member'), 0, 128);
  $verifiedEmail = trim((string)($shop['email'] ?? ''));
  if ($verifiedEmail === '') {
    $identifier = trim((string)($shop['identifier'] ?? ''));
    if (filter_var($identifier, FILTER_VALIDATE_EMAIL)) $verifiedEmail = $identifier;
  }
  $verifiedEmail = mb_strtolower($verifiedEmail);
  if ($verifiedEmail !== '') {
    $stmt = $pdo->prepare("SELECT id, username, display_name FROM users
      WHERE LOWER(username) = ? AND role = 'superadmin' AND is_active = 1 AND shop_user_id IS NULL LIMIT 1");
    $stmt->execute([$verifiedEmail]);
    $admin = $stmt->fetch();
    if ($admin) {
      return [
        'sub' => $admin['id'],
        'role' => 'superadmin',
        'name' => $admin['display_name'],
        'username' => $admin['username'],
      ];
    }
  }

  // All non-matching shop identities use a separate account record. An
  // existing account may have been promoted by a superadmin.
  $shopUsername = $verifiedEmail !== '' && mb_strlen($verifiedEmail) <= 64
    ? $verifiedEmail
    : 'mena_' . substr(hash('sha256', $shop['id']), 0, 56);
  $stmt = $pdo->prepare("INSERT INTO users (id, username, password_hash, display_name, role, shop_user_id)
    VALUES (?, ?, ?, ?, 'member', ?) ON DUPLICATE KEY UPDATE display_name = VALUES(display_name)");
  $stmt->execute([uuid4(), $shopUsername,
    password_hash(bin2hex(random_bytes(32)), PASSWORD_BCRYPT), $name, $shop['id']]);
  $stmt = $pdo->prepare('SELECT * FROM users WHERE shop_user_id = ?');
  $stmt->execute([$shop['id']]);
  $user = $stmt->fetch();
  if (!$user || !$user['is_active'] || !in_array($user['role'], ['member', 'superadmin'], true)) json_error('This account cannot access GuestLink.', 403);
  return ['sub' => $user['id'], 'role' => $user['role'] === 'superadmin' ? 'superadmin' : 'member', 'name' => $name,
    'username' => (string)($shop['email'] ?? $shop['identifier'] ?? '')];
}
