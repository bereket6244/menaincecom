<?php
/**
 * Domain helpers: token generation, row shaping, capacity + status rules.
 */

declare(strict_types=1);

// 80 words × 5 picks ≈ 3.3 billion combinations (~32 bits). Combined with the
// per-IP rate limit on public lookups this puts brute force out of reach.
// Only ever APPEND words: existing guests keep their issued tokens.
const BACKUP_WORDS = [
  'FLOWER','CHAIR','TABLE','MOUSE','PHONE','WATER','STONE','APPLE','GREEN','LIGHT',
  'BREAD','EARTH','GLASS','HOUSE','WATCH','HEART','SMART','SMILE','SHINE','CLOUD',
  'MOUNT','BEACH','SWEET','NIGHT','OCEAN','RIVER','STORM','WINDY','SUNNY','AMBER',
  'BRONZE','SILVER','GOLDEN','PEARL','COPPER','BRAVE','CLEVER','HAPPY','JOLLY','UNITY',
  'TIGER','EAGLE','ZEBRA','PIANO','CANDLE','GARDEN','WINDOW','CIRCLE','SQUARE','ORANGE',
  'PURPLE','YELLOW','INDIGO','CORAL','IVORY','LEMON','MANGO','PEACH','GRAPE','MELON',
  'BERRY','OLIVE','CEDAR','MAPLE','WILLOW','BAMBOO','LOTUS','TULIP','DAISY','ORCHID',
  'FALCON','RABBIT','TURTLE','PARROT','ROBIN','SALMON','CAMEL','PANDA','KOALA','LLAMA',
];

/** Cryptographically random 32-char hex invite token. */
function generate_guest_token(): string {
  return bin2hex(random_bytes(16));
}

/** Five-word backup token, crypto-random word picks. */
function generate_backup_token(): string {
  $words = [];
  for ($i = 0; $i < 5; $i++) {
    $words[] = BACKUP_WORDS[random_int(0, count(BACKUP_WORDS) - 1)];
  }
  return implode(' ', $words);
}

/** Random uppercase access code, e.g. K3F9XQ. */
function generate_access_code(int $length = 8): string {
  $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I confusion
  $out = '';
  for ($i = 0; $i < $length; $i++) {
    $out .= $alphabet[random_int(0, strlen($alphabet) - 1)];
  }
  return $out;
}

function guest_status_for(int $checkedIn, int $allowed, string $current): string {
  if ($current === 'declined') return 'declined';
  if ($checkedIn <= 0) return 'pending';
  return $checkedIn >= $allowed ? 'completed' : 'partial';
}

/** Event row → API shape. Never exposes password_hash. */
function shape_event(array $row): array {
  return [
    'id'               => $row['id'],
    'user_id'          => $row['user_id'],
    'name'             => $row['name'],
    'date'             => $row['date'],
    'venue'            => $row['venue'],
    'notes'            => $row['notes'],
    'access_code'      => $row['access_code'],
    'guest_limit'      => (int)$row['guest_limit'],
    'rsvp_enabled'     => (bool)$row['rsvp_enabled'],
    'services_paused'  => (bool)$row['services_paused'],
    // NULL means "auto" (the client falls back to a date-based default); an
    // explicit true/false is a saved gate-scanning override.
    'scanner_enabled'  => array_key_exists('scanner_enabled', $row) && $row['scanner_enabled'] !== null
                            ? (bool)$row['scanner_enabled'] : null,
    'is_deleted'       => (bool)$row['is_deleted'],
    'created_at'       => $row['created_at'],
    // aggregates, present when the query joins them
    'guests_count'     => isset($row['guests_count']) ? (int)$row['guests_count'] : null,
    'checked_in_count' => isset($row['agg_checked_in']) ? (int)$row['agg_checked_in'] : null,
  ];
}

/** Public (guest-facing) event shape: no credentials at all. */
function shape_event_public(array $row): array {
  $shaped = shape_event($row);
  unset($shaped['access_code'], $shaped['user_id']);
  return $shaped;
}

function shape_guest(array $row): array {
  return [
    'id'               => $row['id'],
    'event_id'         => $row['event_id'],
    'name'             => $row['name'],
    'allowed_count'    => (int)$row['allowed_count'],
    'checked_in_count' => (int)$row['checked_in_count'],
    'status'           => $row['status'],
    'token'            => $row['token'],
    'backup_token'     => $row['backup_token'],
    'is_deleted'       => (bool)$row['is_deleted'],
    'created_at'       => $row['created_at'],
  ];
}

function fetch_event_or_404(string $eventId): array {
  $stmt = db()->prepare('SELECT * FROM events WHERE id = ? AND is_deleted = 0');
  $stmt->execute([$eventId]);
  $row = $stmt->fetch();
  if (!$row) json_error('Event not found.', 404);
  return $row;
}

function fetch_guest_or_404(string $guestId): array {
  $stmt = db()->prepare('SELECT * FROM guests WHERE id = ? AND is_deleted = 0');
  $stmt->execute([$guestId]);
  $row = $stmt->fetch();
  if (!$row) json_error('Guest not found.', 404);
  return $row;
}

/**
 * Total allocated seats for an event excluding declined + deleted guests.
 * $excludeGuestId lets updates re-count without the guest being edited.
 */
function allocated_seats(PDO $pdo, string $eventId, ?string $excludeGuestId = null): int {
  $sql = "SELECT COALESCE(SUM(allowed_count), 0) AS total FROM guests
          WHERE event_id = ? AND is_deleted = 0 AND status != 'declined'";
  $params = [$eventId];
  if ($excludeGuestId !== null) {
    $sql .= ' AND id != ?';
    $params[] = $excludeGuestId;
  }
  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);
  return (int)$stmt->fetch()['total'];
}
