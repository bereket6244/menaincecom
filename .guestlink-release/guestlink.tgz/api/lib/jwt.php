<?php
/**
 * Minimal HS256 JWT — no composer dependency needed on shared hosting.
 */

declare(strict_types=1);

function b64url_encode(string $data): string {
  return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function b64url_decode(string $data): string {
  return base64_decode(strtr($data, '-_', '+/'));
}

function jwt_sign(array $claims): string {
  global $CONFIG;
  $header = b64url_encode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
  $claims['iat'] = time();
  $claims['exp'] = time() + (int)($CONFIG['jwt_ttl'] ?? 43200);
  $payload = b64url_encode(json_encode($claims));
  $sig = b64url_encode(hash_hmac('sha256', "$header.$payload", $CONFIG['jwt_secret'], true));
  return "$header.$payload.$sig";
}

/** Returns the claims array, or null when invalid/expired. */
function jwt_verify(string $token): ?array {
  global $CONFIG;
  $parts = explode('.', $token);
  if (count($parts) !== 3) return null;
  [$header, $payload, $sig] = $parts;
  $expected = b64url_encode(hash_hmac('sha256', "$header.$payload", $CONFIG['jwt_secret'], true));
  if (!hash_equals($expected, $sig)) return null;
  $claims = json_decode(b64url_decode($payload), true);
  if (!is_array($claims)) return null;
  if (($claims['exp'] ?? 0) < time()) return null;
  return $claims;
}

/**
 * Authenticated session or 401.
 * Claims: sub (user/event id), role ('superadmin'|'event'), name, event_id (couples only).
 */
function require_auth(): array {
  $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
  if ($header === '' && function_exists('apache_request_headers')) {
    $headers = apache_request_headers();
    $header = $headers['Authorization'] ?? $headers['authorization'] ?? '';
  }
  if (!preg_match('/^Bearer\s+(.+)$/i', $header, $m)) {
    json_error('Authentication required.', 401);
  }
  $claims = jwt_verify(trim($m[1]));
  if ($claims === null) {
    json_error('Session expired or invalid. Please sign in again.', 401);
  }
  if (in_array(($claims['role'] ?? ''), ['member', 'superadmin'], true)) {
    $stmt = db()->prepare('SELECT role FROM users WHERE id = ? AND is_active = 1');
    $stmt->execute([$claims['sub'] ?? '']);
    $currentRole = $stmt->fetchColumn();
    if (!$currentRole || $currentRole !== $claims['role']) json_error('Your account permissions changed. Please sign in again.', 401);
  }
  return $claims;
}

function require_superadmin(array $session): void {
  if (($session['role'] ?? '') !== 'superadmin') {
    json_error('Administrator privileges required.', 403);
  }
}

/** Couples may only touch their own event; superadmin may touch any. */
function require_event_access(array $session, string $eventId): void {
  if (($session['role'] ?? '') === 'superadmin') return;
  if (($session['role'] ?? '') === 'event' && ($session['event_id'] ?? '') === $eventId) return;
  if (($session['role'] ?? '') === 'member') {
    $stmt = db()->prepare('SELECT 1 FROM events WHERE id = ? AND user_id = ? AND is_deleted = 0');
    $stmt->execute([$eventId, $session['sub']]);
    if ($stmt->fetchColumn()) return;
  }
  json_error('You do not have access to this event.', 403);
}

/** Event management is available to administrators and the owning member only. */
function require_event_manager(array $session, ?string $eventId = null): void {
  if (($session['role'] ?? '') === 'superadmin') return;
  if (($session['role'] ?? '') !== 'member') json_error('Event owner access required.', 403);
  if ($eventId !== null) require_event_access($session, $eventId);
}
