<?php
/**
 * Shared bootstrap: config, DB connection, JSON helpers, CORS.
 * Every request goes through index.php which requires this file.
 */

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '0'); // never leak stack traces to clients

$configPath = __DIR__ . '/../config.php';
if (!file_exists($configPath)) {
  http_response_code(500);
  header('Content-Type: application/json');
  echo json_encode(['error' => 'Server not configured. Copy config.sample.php to config.php.']);
  exit;
}
$CONFIG = require $configPath;

// ---------- CORS ----------
$origin = $CONFIG['cors_origin'] ?? '';
if ($origin !== '') {
  header('Access-Control-Allow-Origin: ' . $origin);
  header('Vary: Origin');
} else {
  // Same-origin deployments: still answer preflights from the same site.
  if (!empty($_SERVER['HTTP_ORIGIN'])) {
    header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
    header('Vary: Origin');
  }
}
header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Max-Age: 86400');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
  http_response_code(204);
  exit;
}

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

// ---------- Database ----------
function db(): PDO {
  static $pdo = null;
  global $CONFIG;
  if ($pdo === null) {
    try {
      $pdo = new PDO(
        'mysql:host=' . $CONFIG['db_host'] . ';dbname=' . $CONFIG['db_name'] . ';charset=utf8mb4',
        $CONFIG['db_user'],
        $CONFIG['db_pass'],
        [
          PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
          PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
          PDO::ATTR_EMULATE_PREPARES => false,
        ]
      );
    } catch (PDOException $e) {
      json_error('Database connection failed.', 500);
    }
  }
  return $pdo;
}

// ---------- JSON helpers ----------
function json_out($data, int $status = 200): void {
  http_response_code($status);
  echo json_encode($data);
  exit;
}

function json_error(string $message, int $status = 400): void {
  json_out(['error' => $message], $status);
}

function read_json_body(): array {
  $raw = file_get_contents('php://input');
  if ($raw === '' || $raw === false) return [];
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

function client_ip(): string {
  return substr($_SERVER['REMOTE_ADDR'] ?? 'unknown', 0, 45);
}

function uuid4(): string {
  $b = random_bytes(16);
  $b[6] = chr((ord($b[6]) & 0x0f) | 0x40);
  $b[8] = chr((ord($b[8]) & 0x3f) | 0x80);
  return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($b), 4));
}

// ---------- Audit log ----------
function audit(string $actor, string $actorRole, string $action, ?string $target = null, ?string $detail = null): void {
  try {
    $stmt = db()->prepare(
      'INSERT INTO audit_logs (actor, actor_role, action, target, detail, ip_address) VALUES (?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([
      substr($actor, 0, 128),
      substr($actorRole, 0, 32),
      substr($action, 0, 64),
      $target !== null ? substr($target, 0, 128) : null,
      $detail,
      client_ip(),
    ]);
  } catch (Throwable $e) {
    // auditing must never break the request itself
  }
}

// ---------- Rate limiting ----------
/** Returns true when the caller is still within the limit. */
function rate_limit_check(string $bucketName, int $maxAttempts, int $windowSeconds): bool {
  $bucket = substr($bucketName . ':' . client_ip(), 0, 160);
  $pdo = db();
  $pdo->prepare('DELETE FROM rate_limits WHERE window_end < NOW()')->execute();
  $stmt = $pdo->prepare('SELECT attempts, window_end FROM rate_limits WHERE bucket = ?');
  $stmt->execute([$bucket]);
  $row = $stmt->fetch();
  if (!$row) {
    $pdo->prepare('INSERT INTO rate_limits (bucket, attempts, window_end) VALUES (?, 1, DATE_ADD(NOW(), INTERVAL ? SECOND))')
        ->execute([$bucket, $windowSeconds]);
    return true;
  }
  if ((int)$row['attempts'] >= $maxAttempts) return false;
  $pdo->prepare('UPDATE rate_limits SET attempts = attempts + 1 WHERE bucket = ?')->execute([$bucket]);
  return true;
}
