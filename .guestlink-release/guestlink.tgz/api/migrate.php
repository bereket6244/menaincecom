<?php
/**
 * Manual database migration runner with a per-step report.
 *
 * You normally don't need this: the API self-migrates on the first request
 * after a deploy (see ensure_schema() in lib/schema.php). Use this only to see
 * exactly which steps ran, or to force a re-run.
 *
 *   https://yourdomain.com/guestlink/api/migrate.php?key=YOUR_SETUP_KEY
 *
 * Every statement is idempotent and safe to repeat. Delete this file afterwards
 * (or rotate setup_key).
 */

declare(strict_types=1);

require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/schema.php';

global $CONFIG;

$key = (string)($_GET['key'] ?? '');
if ($key === '' || !hash_equals((string)$CONFIG['setup_key'], $key)) {
  json_error('Invalid setup key.', 403);
}
if (strpos((string)$CONFIG['setup_key'], 'CHANGE-ME') === 0) {
  json_error('Refusing to run: set a real setup_key in config.php first.', 400);
}

$pdo = db();
$results = run_schema_migrations($pdo);

$labels = array_map(
  fn($step) => ($step['ok'] ? 'OK   ' : 'FAIL ') . $step['label'],
  $results
);
$failed = array_values(array_filter($results, fn($step) => !$step['ok']));

if ($failed) {
  audit('superadmin', 'superadmin', 'migrate.partial');
  json_out([
    'ok'      => false,
    'message' => 'Some migration steps failed. Fix the errors below and re-run — completed steps are safe to repeat.',
    'results' => $labels,
    'errors'  => array_map(fn($step) => ['step' => $step['label'], 'error' => $step['error']], $failed),
  ], 500);
}

// Record the version so the on-boot check skips the work next time.
try {
  $pdo->exec(
    "CREATE TABLE IF NOT EXISTS schema_migrations (
       id         VARCHAR(64) NOT NULL PRIMARY KEY,
       applied_at TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP
     ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
  );
  $pdo->prepare("INSERT IGNORE INTO schema_migrations (id) VALUES (?)")->execute([SCHEMA_VERSION]);
} catch (Throwable $e) {
  // Non-fatal: the schema itself is already up to date.
}

audit('superadmin', 'superadmin', 'migrate.success');
json_out([
  'ok'      => true,
  'message' => 'Database is up to date. Scanner state, invitation designs, and templates now persist. You may delete migrate.php from the server.',
  'results' => $labels,
]);
